import eztool
from eztool import pyxl_handler

if __name__ == "__main__":
    print(eztool.t_now())
    print(eztool.__version__)